-- =============================================
-- Author:		Devrim Ersanli
-- Create date: 3/6/2017
-- Description:	Test SP
-- =============================================
CREATE PROCEDURE EatKek 
	-- Add the parameters for the stored procedure here
	@p1 int = 0, 
	@p2 int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT @p1, @p2
END
GO
